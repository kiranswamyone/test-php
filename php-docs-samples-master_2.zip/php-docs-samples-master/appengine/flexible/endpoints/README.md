# Google Cloud Endpoints & App Engine Flexible Environment & PHP

This sample demonstrates how to use Google Cloud Endpoints on Google App Engine
Flexible Environment using PHP.

The sample code lives in [a parent endpoints directory][1].

[1]: ../../../endpoints/getting-started
