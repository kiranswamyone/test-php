<h1>Contacts</h1>

<h2>Hello, <?= $_GET['name'] ?? ' PHP user!'; ?></h2>
<p>There's nothing else here, you can go <a href="/">back now</a>.</p>
