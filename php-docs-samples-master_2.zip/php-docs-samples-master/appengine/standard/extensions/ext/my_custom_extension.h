// module constants
#define PHP_MY_CUSTOM_EXTENSION_EXTNAME "my_custom_extension"
#define PHP_MY_CUSTOM_EXTENSION_VERSION "0.0.1"

// the function to be exported
PHP_FUNCTION(helloworld_from_extension);
