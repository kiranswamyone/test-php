# Cloud SQL on App Engine Standard for PHP 7.2

This sample has been moved to [cloud_sql](../../../cloud_sql).
