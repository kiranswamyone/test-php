<?php

echo helloworld_from_extension();
