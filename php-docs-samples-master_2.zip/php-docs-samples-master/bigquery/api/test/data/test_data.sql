-- This file is used to test ../../src/insert_sql.php
-- These are comments.
-- Each query to be executed should be on a single line.

/* Another ignored line. */
INSERT INTO `test_table` (`name`, `title`) VALUES ('Brent Shaffer', 'PHP Developer')
INSERT INTO `test_table` (`name`, `title`) VALUES ('Takashi Matsuo', 'Developer\'s Liberation Activist')
INSERT INTO `test_table` (`name`, `title`) VALUES ('Jeffrey Rennie', 'The Man, The Myth, The Legend')
